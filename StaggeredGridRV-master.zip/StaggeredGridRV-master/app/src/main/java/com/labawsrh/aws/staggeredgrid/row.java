package com.labawsrh.aws.staggeredgrid;

public class row {

    private int img;

    public row(int img) {
        this.img = img;
    }


    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }
}
